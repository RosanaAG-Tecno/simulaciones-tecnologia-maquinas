// Constants for the simulation
const MASS = 80; // kg (Rider + Bike)
const GRAVITY = 9.81; // m/s^2
const ROLLING_RESISTANCE_COEF = 0.004; // Asphalt
const AIR_DENSITY = 1.225; // kg/m^3
const FRONTAL_AREA = 0.5; // m^2 (Cyclist area)
const DRAG_COEF = 0.6; // Aerodynamic drag

/**
 * Calculates the steady-state speed given Power and Slope.
 * Since Power = Force * Velocity, and Force depends on Velocity (drag),
 * we need to find V where Power_input = Power_resistive.
 * Power_resistive = (F_gravity + F_rolling + F_drag) * v
 * Power_input = (m*g*sin(theta) + m*g*cos(theta)*Crr + 0.5*rho*A*Cd*v^2) * v
 * This creates a cubic equation for v: A*v^3 + B*v - P = 0
 */
export const calculatePhysics = (watts: number, slopePercent: number) => {
  const theta = Math.atan(slopePercent / 100);
  
  // Coefficients for resistive forces
  const F_gravity = MASS * GRAVITY * Math.sin(theta);
  const F_rolling = MASS * GRAVITY * Math.cos(theta) * ROLLING_RESISTANCE_COEF;
  
  // Drag constant K where F_drag = K * v^2
  const K_drag = 0.5 * AIR_DENSITY * FRONTAL_AREA * DRAG_COEF;

  // We need to solve: K_drag * v^3 + (F_gravity + F_rolling) * v - watts = 0
  // Using Newton-Raphson method for approximation
  let v = 10; // Initial guess in m/s
  for(let i=0; i<10; i++) {
    const f_v = K_drag * Math.pow(v, 3) + (F_gravity + F_rolling) * v - watts;
    const f_prime_v = 3 * K_drag * Math.pow(v, 2) + (F_gravity + F_rolling);
    const next_v = v - f_v / f_prime_v;
    if (Math.abs(next_v - v) < 0.01) {
      v = next_v;
      break;
    }
    v = next_v;
  }
  
  // Ensure non-negative speed
  v = Math.max(0, v);

  const speedKmh = v * 3.6;
  const totalResistiveForce = (watts / v) || 0; // F = P / v

  return {
    speedMs: v,
    speedKmh: speedKmh,
    forceGravity: F_gravity,
    forceDrag: K_drag * Math.pow(v, 2),
    forceRolling: F_rolling,
    totalForce: totalResistiveForce
  };
};