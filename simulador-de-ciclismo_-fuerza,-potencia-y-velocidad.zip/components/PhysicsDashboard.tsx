import React from 'react';
import { 
  LineChart, 
  Line, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer, 
  ReferenceDot,
  Label
} from 'recharts';
import { Activity, Gauge, ArrowUpRight, TrendingDown } from 'lucide-react';
import { calculatePhysics } from '../utils/physics';

interface PhysicsDashboardProps {
  slope: number;
  power: number;
  speedKmh: number;
  totalForce: number;
  gravityForce: number;
}

const PhysicsDashboard: React.FC<PhysicsDashboardProps> = ({ 
  slope, 
  power, 
  speedKmh, 
  totalForce,
  gravityForce
}) => {

  // Generate data for the chart to show the curve of Force vs Speed for the CURRENT Power
  // P = F * v  =>  v = P / F
  const chartData = [];
  for (let f = 10; f <= 300; f += 10) {
    const v_ms = power / f;
    const v_kmh = v_ms * 3.6;
    if (v_kmh < 100) { // Limit chart scale
      chartData.push({ force: f, speed: v_kmh });
    }
  }

  // Generate comparison data: What if we kept the Slope constant but changed power?
  // Or kept Power constant and changed Slope? 
  // Let's visualize the "Hill Effect": Speed vs Slope (at current Power)
  const slopeData = [];
  for (let s = 0; s <= 15; s += 1) {
    const phys = calculatePhysics(power, s);
    slopeData.push({ slope: s, speed: phys.speedKmh });
  }

  return (
    <div className="mt-8 grid grid-cols-1 lg:grid-cols-2 gap-6">
      
      {/* Numerical Stats Cards */}
      <div className="col-span-1 lg:col-span-2 grid grid-cols-2 md:grid-cols-4 gap-4">
        <div className="bg-white p-4 rounded-xl shadow border border-slate-200 flex flex-col items-center">
            <Gauge className="text-blue-500 mb-2" size={24} />
            <span className="text-slate-500 text-sm font-semibold">Velocidad</span>
            <span className="text-3xl font-bold text-slate-800">{speedKmh.toFixed(1)} <span className="text-sm font-normal text-slate-500">km/h</span></span>
        </div>
        <div className="bg-white p-4 rounded-xl shadow border border-slate-200 flex flex-col items-center">
            <Activity className="text-amber-500 mb-2" size={24} />
            <span className="text-slate-500 text-sm font-semibold">Potencia (Input)</span>
            <span className="text-3xl font-bold text-slate-800">{power} <span className="text-sm font-normal text-slate-500">W</span></span>
        </div>
        <div className="bg-white p-4 rounded-xl shadow border border-slate-200 flex flex-col items-center">
            <ArrowUpRight className="text-red-500 mb-2" size={24} />
            <span className="text-slate-500 text-sm font-semibold">Fuerza Total</span>
            <span className="text-3xl font-bold text-slate-800">{totalForce.toFixed(0)} <span className="text-sm font-normal text-slate-500">N</span></span>
        </div>
        <div className="bg-white p-4 rounded-xl shadow border border-slate-200 flex flex-col items-center bg-red-50">
            <TrendingDown className="text-red-700 mb-2" size={24} />
            <span className="text-slate-600 text-sm font-semibold">Fuerza Gravedad</span>
            <span className="text-3xl font-bold text-red-800">{gravityForce.toFixed(0)} <span className="text-sm font-normal text-slate-600">N</span></span>
        </div>
      </div>

      {/* Chart 1: Relation Force vs Speed (Constant Power) */}
      <div className="bg-white p-6 rounded-xl shadow border border-slate-200">
        <h3 className="text-lg font-bold text-slate-800 mb-2">Relación Fuerza vs Velocidad</h3>
        <p className="text-sm text-slate-500 mb-4">
          A una potencia constante de <strong>{power}W</strong>: Si la fuerza necesaria aumenta (por la pendiente), la velocidad disminuye drásticamente.
        </p>
        <div className="h-64 w-full">
          <ResponsiveContainer width="100%" height="100%">
            <LineChart data={chartData} margin={{ top: 20, right: 30, left: 20, bottom: 20 }}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis 
                type="number" 
                dataKey="force" 
                label={{ value: 'Fuerza (N)', position: 'insideBottom', offset: -10 }} 
                domain={[0, 300]}
              />
              <YAxis 
                label={{ value: 'Velocidad (km/h)', angle: -90, position: 'insideLeft' }}
              />
              <Tooltip formatter={(value: number) => value.toFixed(1)} />
              <Line type="monotone" dataKey="speed" stroke="#3b82f6" strokeWidth={3} dot={false} isAnimationActive={false} />
              <ReferenceDot x={totalForce} y={speedKmh} r={6} fill="#dc2626" stroke="none">
                <Label value="Estado Actual" position="top" />
              </ReferenceDot>
            </LineChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Chart 2: Effect of Slope on Speed */}
      <div className="bg-white p-6 rounded-xl shadow border border-slate-200">
        <h3 className="text-lg font-bold text-slate-800 mb-2">Impacto de la Pendiente</h3>
        <p className="text-sm text-slate-500 mb-4">
          Cómo decae la velocidad al aumentar la inclinación, manteniendo {power}W.
        </p>
        <div className="h-64 w-full">
          <ResponsiveContainer width="100%" height="100%">
            <LineChart data={slopeData} margin={{ top: 20, right: 30, left: 20, bottom: 20 }}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis 
                dataKey="slope" 
                label={{ value: 'Pendiente (%)', position: 'insideBottom', offset: -10 }} 
              />
              <YAxis 
                label={{ value: 'Velocidad (km/h)', angle: -90, position: 'insideLeft' }}
                domain={[0, 'auto']}
              />
              <Tooltip formatter={(value: number) => value.toFixed(1)} />
              <Line type="monotone" dataKey="speed" stroke="#10b981" strokeWidth={3} dot={true} />
              <ReferenceDot x={slope} y={speedKmh} r={6} fill="#dc2626" stroke="none" />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </div>

    </div>
  );
};

export default PhysicsDashboard;