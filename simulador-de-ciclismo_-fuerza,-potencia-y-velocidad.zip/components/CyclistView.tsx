import React, { useEffect, useRef, useState } from 'react';

interface CyclistViewProps {
  slope: number;
  speedKmh: number;
}

const CyclistView: React.FC<CyclistViewProps> = ({ slope, speedKmh }) => {
  const requestRef = useRef<number>(0);
  const [state, setState] = useState({
    treeOffset: 0,
    crankAngle: 0, // Degrees
    wheelAngle: 0
  });

  // Constantes de Geometría de la Bici
  const groundY = 240;
  const wheelRadius = 35;
  const wheelY = groundY - wheelRadius; // 205
  const rearWheelX = 100;
  const frontWheelX = 260;
  const bbX = 170; // Bottom Bracket X (Eje pedalier)
  const bbY = wheelY + 10; 
  const crankLength = 18;
  
  const hipX = 140;
  const hipY = 130;
  const thighLen = 50;
  const shinLen = 50;

  const shoulderX = 180;
  const shoulderY = 90;
  const handX = 230;
  const handY = 140;

  // Bucle de animación
  const animate = () => {
    setState(prev => {
      // Factor de velocidad visual
      const speedFactor = speedKmh / 10; 
      
      // Actualizar fondo (árboles)
      const newTreeOffset = (prev.treeOffset - (speedFactor * 1.5)) % 1000;
      
      // Actualizar rotación de ruedas y pedales
      // speedKmh -> rotación. Ajustado para que visualmente sea agradable.
      const rotationStep = speedKmh * 0.8; 
      
      return {
        treeOffset: newTreeOffset,
        crankAngle: (prev.crankAngle + rotationStep) % 360,
        wheelAngle: (prev.wheelAngle + rotationStep) % 360
      };
    });
    requestRef.current = requestAnimationFrame(animate);
  };

  useEffect(() => {
    requestRef.current = requestAnimationFrame(animate);
    return () => cancelAnimationFrame(requestRef.current);
  }, [speedKmh]);

  // Cinemática Inversa para la pierna
  // Calcula la posición de la rodilla dados la cadera y el pedal
  const calculateLeg = (angleOffset: number) => {
    const angleRad = ((state.crankAngle + angleOffset) * Math.PI) / 180;
    
    // Posición del Pedal
    const pedalX = bbX + crankLength * Math.cos(angleRad);
    const pedalY = bbY + crankLength * Math.sin(angleRad);
    
    // Resolver triángulo para la rodilla (Ley de cosenos)
    // Distancia Cadera a Pedal
    const dist = Math.sqrt((pedalX - hipX) ** 2 + (pedalY - hipY) ** 2);
    // Ángulo Cadera a Pedal
    const alpha = Math.atan2(pedalY - hipY, pedalX - hipX);
    // Ángulo interno en la cadera
    const cosAngle = (thighLen ** 2 + dist ** 2 - shinLen ** 2) / (2 * thighLen * dist);
    // Clamp para evitar errores matemáticos si el pedal está muy lejos
    const clampedCos = Math.max(-1, Math.min(1, cosAngle));
    const angleHipInternal = Math.acos(clampedCos);
    
    // Ángulo final del muslo. Restamos el ángulo interno para que la rodilla apunte hacia "arriba/adelante"
    const kneeAngle = alpha - angleHipInternal;
    
    const kneeX = hipX + thighLen * Math.cos(kneeAngle);
    const kneeY = hipY + thighLen * Math.sin(kneeAngle);

    return { pedalX, pedalY, kneeX, kneeY };
  };

  const rightLeg = calculateLeg(0);
  const leftLeg = calculateLeg(180);

  // Rotación de la carretera (Pendiente)
  // Rotamos alrededor del punto de contacto de la rueda trasera para mantener la bici "pegada" al suelo visualmente
  const visualRotation = -Math.min(slope, 20); 

  return (
    <div className="relative w-full h-96 overflow-hidden bg-sky-200 rounded-xl border-4 border-slate-800 shadow-xl">
      {/* Fondo - Cielo y Sol */}
      <div className="absolute top-5 right-5 w-16 h-16 bg-yellow-400 rounded-full opacity-90 shadow-[0_0_50px_rgba(255,223,0,0.8)] animate-pulse"></div>
      
      {/* Nubes */}
      <div className="absolute top-10 left-10 text-white opacity-80 scale-150">☁️</div>
      <div className="absolute top-20 left-1/2 text-white opacity-60 scale-125">☁️</div>

      {/* Árboles Parallax - Capa Lejana */}
      <div 
        className="absolute bottom-32 left-0 h-40 w-[200%] flex opacity-60"
        style={{ transform: `translateX(${state.treeOffset * 0.4}px)` }}
      >
        {Array.from({ length: 15 }).map((_, i) => (
           <div key={i} className="w-32 h-40 mx-8 flex flex-col items-center justify-end">
             <div className="w-24 h-32 bg-emerald-800 rounded-full"></div>
             <div className="w-4 h-10 bg-amber-900"></div>
           </div>
        ))}
      </div>

      {/* Árboles Parallax - Capa Cercana */}
      <div 
        className="absolute bottom-0 left-0 h-56 w-[200%] flex"
        style={{ transform: `translateX(${state.treeOffset}px)` }}
      >
        {Array.from({ length: 10 }).map((_, i) => (
           <div key={`near-${i}`} className="w-48 h-56 mx-12 flex flex-col items-center justify-end">
             <div className="w-40 h-40 bg-green-700 rounded-full shadow-lg border-b-8 border-green-900"></div>
             <div className="w-6 h-20 bg-amber-950"></div>
           </div>
        ))}
      </div>

      {/* Contenedor Principal de la Escena (Rota con la pendiente) */}
      <div 
        className="absolute bottom-10 left-10 w-full h-full transition-transform duration-500 ease-out origin-[100px_240px]" 
        style={{ transform: `rotate(${visualRotation}deg)` }}
      >
        {/* Superficie de la Carretera */}
        <div className="absolute top-[240px] left-[-50%] w-[300%] h-40 bg-slate-700 border-t-8 border-slate-600 origin-top">
             {/* Marcas viales */}
             <div className="w-full h-2 mt-4 border-t-2 border-dashed border-slate-400 opacity-50"></div>
        </div>

        {/* SVG Bici y Ciclista */}
        <svg viewBox="0 0 400 300" className="absolute top-0 left-0 w-full h-full overflow-visible">
            
            {/* Pierna Izquierda (Detrás) */}
            <g strokeLinecap="round" strokeLinejoin="round">
                <line x1={hipX} y1={hipY} x2={leftLeg.kneeX} y2={leftLeg.kneeY} stroke="#7c2d12" strokeWidth="8" />
                <line x1={leftLeg.kneeX} y1={leftLeg.kneeY} x2={leftLeg.pedalX} y2={leftLeg.pedalY} stroke="#7c2d12" strokeWidth="6" />
                <circle cx={leftLeg.pedalX} cy={leftLeg.pedalY} r="4" fill="#333" />
            </g>

            {/* Cuadro de la Bici (Bloque Estático) */}
            <g stroke="#1f2937" strokeWidth="5" fill="none" strokeLinecap="round" strokeLinejoin="round">
                {/* Triángulo Principal */}
                <path d={`M${bbX} ${bbY} L${hipX + 10} ${hipY + 10} L${handX - 20} ${handY - 10} L${bbX} ${bbY}`} fill="#ef4444" stroke="none" opacity="0.1"/>
                <line x1={rearWheelX} y1={wheelY} x2={bbX} y2={bbY} strokeWidth="6" /> {/* Vaina inferior */}
                <line x1={rearWheelX} y1={wheelY} x2={hipX+5} y2={hipY+10} strokeWidth="6" /> {/* Vaina superior */}
                <line x1={bbX} y1={bbY} x2={hipX+5} y2={hipY+10} strokeWidth="6" className="text-blue-600" stroke="#2563eb" /> {/* Tubo sillín */}
                <line x1={bbX} y1={bbY} x2={handX-10} y2={handY-20} strokeWidth="6" stroke="#2563eb" /> {/* Tubo diagonal */}
                <line x1={hipX+5} y1={hipY+10} x2={handX-10} y2={handY-20} strokeWidth="6" stroke="#2563eb" /> {/* Tubo superior */}
                
                {/* Horquilla */}
                <line x1={handX-10} y1={handY-20} x2={frontWheelX} y2={wheelY} strokeWidth="5" />
                
                {/* Manillar y Potencia */}
                <path d={`M${handX-10} ${handY-20} L${handX} ${handY-30} L${handX+10} ${handY-25}`} fill="none" strokeWidth="5"/>
                
                {/* Tija y Sillín */}
                <line x1={hipX+5} y1={hipY+10} x2={hipX} y2={hipY-5} strokeWidth="5" />
                <path d={`M${hipX-10} ${hipY-5} L${hipX+15} ${hipY-5}`} strokeWidth="8" />
            </g>

            {/* Ruedas (Giran sobre su propio eje) */}
            <g transform={`rotate(${state.wheelAngle}, ${rearWheelX}, ${wheelY})`}>
                <circle cx={rearWheelX} cy={wheelY} r={wheelRadius} stroke="black" strokeWidth="4" fill="transparent" />
                <circle cx={rearWheelX} cy={wheelY} r={wheelRadius-4} stroke="#cbd5e1" strokeWidth="2" strokeDasharray="5,5" fill="transparent" />
                {/* Radios */}
                <line x1={rearWheelX} y1={wheelY-wheelRadius} x2={rearWheelX} y2={wheelY+wheelRadius} stroke="#94a3b8" strokeWidth="1" />
                <line x1={rearWheelX-wheelRadius} y1={wheelY} x2={rearWheelX+wheelRadius} y2={wheelY} stroke="#94a3b8" strokeWidth="1" />
                <line x1={rearWheelX-25} y1={wheelY-25} x2={rearWheelX+25} y2={wheelY+25} stroke="#94a3b8" strokeWidth="1" />
                <line x1={rearWheelX+25} y1={wheelY-25} x2={rearWheelX-25} y2={wheelY+25} stroke="#94a3b8" strokeWidth="1" />
            </g>

            <g transform={`rotate(${state.wheelAngle}, ${frontWheelX}, ${wheelY})`}>
                <circle cx={frontWheelX} cy={wheelY} r={wheelRadius} stroke="black" strokeWidth="4" fill="transparent" />
                <circle cx={frontWheelX} cy={wheelY} r={wheelRadius-4} stroke="#cbd5e1" strokeWidth="2" strokeDasharray="5,5" fill="transparent" />
                 {/* Radios */}
                <line x1={frontWheelX} y1={wheelY-wheelRadius} x2={frontWheelX} y2={wheelY+wheelRadius} stroke="#94a3b8" strokeWidth="1" />
                <line x1={frontWheelX-wheelRadius} y1={wheelY} x2={frontWheelX+wheelRadius} y2={wheelY} stroke="#94a3b8" strokeWidth="1" />
                <line x1={frontWheelX-25} y1={wheelY-25} x2={frontWheelX+25} y2={wheelY+25} stroke="#94a3b8" strokeWidth="1" />
                <line x1={frontWheelX+25} y1={wheelY-25} x2={frontWheelX-25} y2={wheelY+25} stroke="#94a3b8" strokeWidth="1" />
            </g>

            {/* Cuerpo del Ciclista (Estático relativo al cuadro) */}
            <g strokeLinecap="round" strokeLinejoin="round">
                 {/* Torso */}
                 <path d={`M${hipX} ${hipY} Q${hipX+10} ${hipY-40} ${shoulderX} ${shoulderY}`} stroke="#3b82f6" strokeWidth="18" fill="none" />
                 {/* Cabeza */}
                 <circle cx={shoulderX+5} cy={shoulderY-15} r="12" fill="#fca5a5" />
                 {/* Casco */}
                 <path d={`M${shoulderX-10} ${shoulderY-20} Q${shoulderX+5} ${shoulderY-35} ${shoulderX+20} ${shoulderY-15}`} stroke="#dc2626" strokeWidth="6" fill="#dc2626" />
                 {/* Brazo */}
                 <line x1={shoulderX} y1={shoulderY} x2={handX} y2={handY} stroke="#3b82f6" strokeWidth="8" />
            </g>

             {/* Pierna Derecha (Delante) */}
             <g strokeLinecap="round" strokeLinejoin="round">
                <line x1={hipX} y1={hipY} x2={rightLeg.kneeX} y2={rightLeg.kneeY} stroke="#b45309" strokeWidth="8" />
                <line x1={rightLeg.kneeX} y1={rightLeg.kneeY} x2={rightLeg.pedalX} y2={rightLeg.pedalY} stroke="#b45309" strokeWidth="6" />
                {/* Biela */}
                <line x1={bbX} y1={bbY} x2={rightLeg.pedalX} y2={rightLeg.pedalY} stroke="#475569" strokeWidth="4" />
                {/* Pedal */}
                <circle cx={rightLeg.pedalX} cy={rightLeg.pedalY} r="5" fill="#111" />
            </g>

        </svg>
      </div>
    </div>
  );
};

export default CyclistView;