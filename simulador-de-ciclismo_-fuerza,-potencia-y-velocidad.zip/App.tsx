import React, { useState, useMemo } from 'react';
import CyclistView from './components/CyclistView';
import PhysicsDashboard from './components/PhysicsDashboard';
import { calculatePhysics } from './utils/physics';

const App: React.FC = () => {
  // State for user inputs
  const [power, setPower] = useState<number>(250); // Watts
  const [slope, setSlope] = useState<number>(0); // Percentage %

  // Calculate real-time physics based on state
  const physicsState = useMemo(() => {
    return calculatePhysics(power, slope);
  }, [power, slope]);

  return (
    <div className="min-h-screen bg-slate-100 p-4 md:p-8 font-sans">
      <div className="max-w-6xl mx-auto">
        
        {/* Header */}
        <header className="mb-8 text-center md:text-left">
          <h1 className="text-3xl md:text-4xl font-extrabold text-slate-900 tracking-tight">
            Simulador de Ciclismo: <span className="text-blue-600">Fuerza, Potencia y Velocidad</span>
          </h1>
          <p className="mt-2 text-lg text-slate-600">
            Explora cómo la inclinación (pendiente) aumenta la fuerza necesaria y reduce la velocidad bajo una potencia constante.
          </p>
        </header>

        {/* Main Simulation Area */}
        <div className="grid grid-cols-1 gap-8">
          
          {/* Visual Canvas */}
          <div className="relative">
            <div className="absolute top-4 left-4 z-10 bg-white/90 backdrop-blur-sm p-3 rounded-lg shadow-sm border border-slate-200 text-xs md:text-sm">
                <div className="flex items-center gap-2">
                    <div className={`w-3 h-3 rounded-full ${slope > 2 ? 'bg-red-500' : 'bg-green-500'}`}></div>
                    <span className="font-semibold">{slope === 0 ? 'Terreno Llano (Fuerza Baja)' : 'Subiendo Cuesta (Fuerza Alta)'}</span>
                </div>
            </div>
            <CyclistView slope={slope} speedKmh={physicsState.speedKmh} />
          </div>

          {/* Controls */}
          <div className="bg-white p-6 rounded-2xl shadow-lg border border-slate-200">
            <h2 className="text-xl font-bold text-slate-800 mb-6 flex items-center gap-2">
              🎛️ Panel de Control
            </h2>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8 md:gap-12">
              
              {/* Slider: Slope */}
              <div className="space-y-4">
                <div className="flex justify-between items-center">
                  <label htmlFor="slope-slider" className="font-semibold text-slate-700">Pendiente (Inclinación)</label>
                  <span className="bg-slate-100 px-3 py-1 rounded-md font-mono text-slate-800 font-bold">{slope}%</span>
                </div>
                <input
                  id="slope-slider"
                  type="range"
                  min="0"
                  max="15"
                  step="0.5"
                  value={slope}
                  onChange={(e) => setSlope(parseFloat(e.target.value))}
                  className="w-full h-3 bg-slate-200 rounded-lg appearance-none cursor-pointer accent-red-600 hover:accent-red-700 transition-all"
                />
                <div className="flex justify-between text-xs text-slate-500">
                  <span>0% (Llano)</span>
                  <span>7% (Duro)</span>
                  <span>15% (Extremo)</span>
                </div>
                <p className="text-sm text-slate-500 mt-2">
                  Al aumentar la pendiente, la gravedad tira del ciclista hacia atrás, aumentando la <strong>Fuerza Resistiva</strong>.
                </p>
              </div>

              {/* Slider: Power */}
              <div className="space-y-4">
                 <div className="flex justify-between items-center">
                  <label htmlFor="power-slider" className="font-semibold text-slate-700">Potencia del Ciclista</label>
                  <span className="bg-blue-50 px-3 py-1 rounded-md font-mono text-blue-800 font-bold">{power} W</span>
                </div>
                <input
                  id="power-slider"
                  type="range"
                  min="100"
                  max="800"
                  step="10"
                  value={power}
                  onChange={(e) => setPower(parseFloat(e.target.value))}
                  className="w-full h-3 bg-slate-200 rounded-lg appearance-none cursor-pointer accent-blue-600 hover:accent-blue-700 transition-all"
                />
                 <div className="flex justify-between text-xs text-slate-500">
                  <span>100W (Suave)</span>
                  <span>400W (Pro)</span>
                  <span>800W (Sprint)</span>
                </div>
                <p className="text-sm text-slate-500 mt-2">
                  La energía por segundo que entrega el ciclista. A mayor potencia, mayor velocidad para la misma fuerza.
                </p>
              </div>

            </div>
          </div>
        </div>

        {/* Analytics Section */}
        <PhysicsDashboard 
          slope={slope}
          power={power}
          speedKmh={physicsState.speedKmh}
          totalForce={physicsState.totalForce}
          gravityForce={physicsState.forceGravity}
        />
        
        {/* Explanation Text */}
        <div className="mt-8 p-6 bg-slate-200 rounded-xl text-slate-700">
            <h3 className="font-bold text-lg mb-2">Conceptos Clave:</h3>
            <ul className="list-disc pl-5 space-y-2">
                <li><strong>Fórmula Base:</strong> Potencia ($P$) = Fuerza ($F$) $\times$ Velocidad ($v$). Por tanto, $v = P / F$.</li>
                <li><strong>Zona Llana (Pendiente 0%):</strong> La fuerza necesaria para mover la bici es baja (solo rozamiento y aire). Resultado: <strong>Alta velocidad</strong>.</li>
                <li><strong>Subiendo Cuesta:</strong> La gravedad añade una componente enorme a la fuerza resistiva. Si mantienes la misma potencia, la velocidad <strong>debe bajar</strong> proporcionalmente al aumento de fuerza.</li>
            </ul>
        </div>

      </div>
    </div>
  );
};

export default App;